<div id="backtotop">
    <a href="#top"><i class="fa fa-chevron-up"></i></a>
</div>
<footer class="footer-wrap">
    <p>Copyright 2016 Student Portal</p>
</footer>
<script src='js/jquery-3.1.1.min.js'></script>
<script src="js/functions.js"></script>
</body>
</html>